function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5lbqBJw7UY6":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

